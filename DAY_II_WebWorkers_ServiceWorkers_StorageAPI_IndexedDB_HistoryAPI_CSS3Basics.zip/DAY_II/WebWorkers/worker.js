//1. No access to window/document
//2. No access to global variable from main thread
//3. Access to XMLHttpRequest/fetch (AJAX), indexedDB

onmessage = function (msg) {
  var largerArray = [];
  for (let i = 0; i < 8000; i++) {
    largerArray[i] = [];
    for (let j = 0; j < 7000; j++) {
      largerArray[i][j] = Math.random();
    }
  }
  postMessage(largerArray[2000][2000]);
};
