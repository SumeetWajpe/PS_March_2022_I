var cacheName = "v3";
var cacheAssets = ["Index.html", "AboutUs.html", "js/script.js"];
//browser
self.addEventListener("install", function (e) {
  // configure the cache
  e.waitUntil(
    caches
      .open(cacheName)
      .then(function (cache) {
        console.log("Service Worker :: Caching files !");
        cache.addAll(cacheAssets);
      })
      .then(function () {
        self.skipWaiting();
      })
  );
});
//activate
self.addEventListener("activate", function (e) {
  console.log("Servce Worker :: activated !");
  e.waitUntil(
    caches.keys().then(function (cachesNames) {
      cachesNames.map(function (c) {
        if (c !== cacheName) {
          return caches.delete(c);
        }
      });
    })
  );
});
// request from the browser
self.addEventListener("fetch", function (e) {
  console.log("Service Worker :: Fetching resources !");
  e.respondWith(
    fetch(e.request).catch(function () {
      return caches.match(e.request); // fetch resource from the cache in case of n/w failure
    })
  );
});
