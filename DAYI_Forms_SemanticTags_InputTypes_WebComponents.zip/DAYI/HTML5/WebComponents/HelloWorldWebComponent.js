// 1st step
class HelloWebComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }

  connectedCallback() {
    var pElement = document.createElement("h2");
    pElement.innerHTML = "Dynamic Para !";
    this.appendChild(pElement);
  }
}

//2nd Step
customElements.define("hello-world", HelloWebComponent);
