const express = require("express");
const path = require("path");
const app = express();
var courses = require("./models/course.model");
var cors = require("cors");
const port = 3000;

app.use(cors()); // This will enable for all APIs
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());

app.get("/courses", (req, res) => {
  res.json(courses);
});

app.delete("/course/:id", (req, res) => {
  //   console.log("Deleting course..", req.params.id);
  let theCourseId = req.params.id;
  // functional programming
  courses = courses.filter((course) => course.id != theCourseId);
  console.log(courses);
  res.json({ msg: "success" });
});

app.post("/newcourse", (req, res) => {
  let courseToBeAdded = req.body;
  courses = [...courses, courseToBeAdded]; // push !
  //   console.log("Adding new course");
  res.json({ msg: "success" });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
