function FullTime() {
  this.salary = 200000;
}
function PartTime() {
  this.salary = 100000;
}
function Contractor() {
  this.dailyWages = 10000;
}
function Freelancer() {
  this.hourlyWages = 5000;
}

export function EmployeeFactory() {
  let emp;
  this.createEmployee = function (type) {
    switch (type) {
      case "Fulltime":
        emp = new FullTime();
        break;
      case "Parttime":
        emp = new PartTime();
        break;
      case "Contractor":
        emp = new Contractor();
        break;
      case "Freelancer":
        emp = new Freelancer();
        break;

      default:
        console.log("Employee type does not match !");

        break;
    }
    emp.type = type;
    return emp;
  };
}
