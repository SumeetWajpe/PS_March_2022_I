function RegisterEventHandler(theObject, theEvent, theEventHandler) {
  if (window.addEventListener) {
    theObject.addEventListener(theEvent, theEventHandler);
  } else if (window.attachEvent) {
    theObject.attachEvent(theEvent, theEventHandler);
  } else {
    theObject["on" + theEvent] = theEventHandler;
  }
}
