function GetPosts(callback) {
  //1. Instanciate XMLHttpRequest
  //2. configure using open()
  //3. make async call - send()
  //4. register for onreadystatechange
  //5. when response arrives display the data

  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.onreadystatechange = function () {
    // success
    if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
      callback(null, xmlHttpReq.response);
    } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
      callback(`Error ${xmlHttpReq.status} !`, null);
    }
  };

  xmlHttpReq.send(); // places the async call
}
