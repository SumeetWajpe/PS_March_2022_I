function GetPosts() {
  return new Promise((resolve, reject) => {
    var xmlHttpReq = new XMLHttpRequest();
    xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlHttpReq.onreadystatechange = function () {
      // success
      if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
        resolve(xmlHttpReq.response);
      } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
        reject(`Error ${xmlHttpReq.status} !`);
      }
    };
    xmlHttpReq.send(); // places the async call
  });
}
