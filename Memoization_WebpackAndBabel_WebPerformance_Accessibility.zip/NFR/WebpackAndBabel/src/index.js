import { Add, Point } from "./module";
console.log("The addition is : " + Add(20, 30));
var pointObj = new Point();
console.log("Point[x,y] : ", pointObj.x, pointObj.y);
